package com.cg.testcases;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.testproject.dao.IStudentDao;
import com.cg.testproject.dao.StudentDaoImpl;
import com.cg.testproject.dto.StudentDto;

class ProjectTestCases {

	IStudentDao dao = new StudentDaoImpl();

	@BeforeClass
	public static void setUp() throws Exception {
		System.out.println("Testing starts");
	}

	@AfterClass
	public static void endUp() throws Exception {
		System.out.println("Testing Ends");
	}

	@Test
	public void getCollegeValidTest() {
		assertEquals("IIT-Chennai", dao.showCollegeName("Chennai"));
	}

	@Test
	public void getCollegeNullTest() {
		assertNull(dao.showCollegeName(" "));
	}

	@Test
	public void addStudentTest() {
		StudentDto studentDto = new StudentDto();
		studentDto.setAge(21);
		studentDto.setCity("Hyderabad");
		studentDto.setEmail("krishna@gmail.com");
		studentDto.setGender("M");
		studentDto.setName("krishna");
		studentDto.setNumber("9176042782");
		dao.addStudent(studentDto);
		assertEquals("IIT-Chennai", dao.showCollegeName("Chennai"));
	}

	@Test
	public void getCollegeInvalidInputsTest() {
		assertNotSame("kolkata", dao.showCollegeName("kolkata"));

	}

	@Test
	public void showStudent() {
		assertNull(null, dao.showStudent(12345));
	}

}
