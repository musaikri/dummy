package com.cg.testproject.service;

import com.cg.testproject.dao.StudentDaoImpl;
import com.cg.testproject.dto.StudentDto;
import com.cg.testproject.exception.IStudentExceptionMessages;
import com.cg.testproject.exception.StudentException;

public class StudentServiceImpl implements IStudentService {

	private StudentDaoImpl dao = null;

	public StudentServiceImpl() {
		dao = new StudentDaoImpl();
	}

	@Override
	public Integer addStudent(StudentDto studentDto) {
		int generatedId = (int) (Math.random() * 9000 + 1000);
		String collegeName = dao.showCollegeName(studentDto.getCity());
		if(null != collegeName) {
			studentDto.setId(generatedId);
			studentDto.setCollege(collegeName);
			studentDto.setStatus("Approved");
			dao.addStudent(studentDto);
		}
		return generatedId;
	}

	@Override
	public StudentDto showStudent(int id) {
		return dao.showStudent(id);
	}

	@Override
	public boolean validationdetails(StudentDto studentDto) throws StudentException {
		boolean result=true;
		if(!(studentDto.getName().matches("[a-zA-Z]+"))) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE1);
		}
		if(!(studentDto.getNumber().matches("[0-9]+") && studentDto.getNumber().length()==10)) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE2);
		}
		if((studentDto.getAge())<1 || (studentDto.getAge()) > 100) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE3);
		}
		if(!(studentDto.getEmail().matches("[a-zA-Z0-9_.]+@[a-z0-9]+.com"))) {
			throw new StudentException(IStudentExceptionMessages.MESSAGE4);
		}
		return result;
	}

}
