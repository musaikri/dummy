package com.cg.librarymanagementdummy.exception;

public class LibraryManagementException extends Exception {

	public LibraryManagementException() {
		super();
	}

	public LibraryManagementException(String message1) {
		super(message1);
	}

}
