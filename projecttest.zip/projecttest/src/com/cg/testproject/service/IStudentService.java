package com.cg.testproject.service;

import com.cg.testproject.dto.StudentDto;
import com.cg.testproject.exception.StudentException;

public interface IStudentService {
	
	public Integer addStudent(StudentDto studentDto);
	public StudentDto showStudent(int id);
	public boolean validationdetails(StudentDto studentDto) throws StudentException;

}
