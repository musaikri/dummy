package com.cg.testproject.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import com.cg.testproject.dto.StudentDto;
import com.cg.testproject.exception.IStudentExceptionMessages;
import com.cg.testproject.exception.StudentException;
import com.cg.testproject.service.IStudentService;
import com.cg.testproject.service.StudentServiceImpl;

public class StudentMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		IStudentService service = new StudentServiceImpl();
		int choice = 0;
		do {
			printDetails();
			System.out.println("Enter choice : ");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:

				System.out.println("Enter name : ");
				String name = scanner.next();
				System.out.println("Enter phone number : ");
				String number = scanner.next();
				System.out.println("Enter email : ");
				String email = scanner.next();
				System.out.println("Enter age : ");
				int age = scanner.nextInt();
				System.out.println("Enter gender : ");
				String gender = scanner.next();
				System.out.println("Enter city where you want to study : ");
				String city = scanner.next();
				System.out.println("Enter date of joining in dd-MMM-yyyy format : ");
				String input1 = scanner.next();
				try {
					DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
					LocalDate doj = LocalDate.parse(input1, dateTimeFormatter);
					StudentDto studentDto = new StudentDto();
					studentDto.setAge(age);
					studentDto.setCity(city);
					studentDto.setEmail(email);
					studentDto.setGender(gender);
					studentDto.setName(name);
					studentDto.setNumber(number);
					studentDto.setDateOfJoining(doj);
					boolean result = false;
					try {
						result = service.validationdetails(studentDto);
					} catch (StudentException stException) {
						System.out.println(stException.getMessage());
					}
					if (result) {
						int id = service.addStudent(studentDto);
						System.out.println(id);
					}
				} catch (DateTimeParseException exception) {
					try {
						throw new StudentException(IStudentExceptionMessages.MESSAGE5);
					} catch (StudentException studentException) {
						System.out.println(studentException.getMessage());
					}
				}
				break;
			case 2:
				System.out.println("Enter id : ");
				int idd = scanner.nextInt();
				StudentDto dto = service.showStudent(idd);
				if (dto != null) {
					System.out.println("Studentname : " + dto.getName());
					System.out.println("Status : " + dto.getStatus());
					System.out.println("College : " + dto.getCollege());
				} else {
					System.out.println("Student not found....");
				}
				break;
			case 3:
				// System.out.println("Thanks for using....");
				System.exit(0);
				break;
			default:
				break;
			}
		} while (choice != 4);
		scanner.close();

	}

	private static void printDetails() {
		System.out.println("\nMenu");
		System.out.println("==========");
		System.out.println("1.Add Student details\n2. View Student Status\n3.Exit");
	}
}
