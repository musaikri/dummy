package com.cg.librarymanagementdummy.exception;

public interface ILibraryManagementExceptionMessages {

	String MESSAGE1 = "\nEnter Valid MemberID...!!!\n";
	String MESSAGE2 = "\nAmount Should be Numerical Only...!!!\n";

}
