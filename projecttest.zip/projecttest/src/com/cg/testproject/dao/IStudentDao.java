package com.cg.testproject.dao;

import com.cg.testproject.dto.StudentDto;

public interface IStudentDao {
	
	public String showCollegeName(String city);
	public StudentDto showStudent(int id);
	public void addStudent(StudentDto studentDto);
	

}
