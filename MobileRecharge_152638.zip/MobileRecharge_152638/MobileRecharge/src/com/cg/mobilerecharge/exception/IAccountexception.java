package com.cg.mobilerecharge.exception;

public interface IAccountexception {

	String MESSAGE1 = "\nPlease Enter Valid Mobile Number...!!!\n";
	String MESSAGE2 = "\nPlease Enter Valid Amount...!!!\n";
	String MESSAGE3 = "\nPlease Enter Valid Inputs Only i.e Integer Only...!!!\n";

}
