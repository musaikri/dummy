package com.cg.testproject.exception;

public interface IStudentExceptionMessages {
	
	String MESSAGE1 = "Name should be only alpghabets";
	String MESSAGE2 = "Phone numbers should be only numbers and of 10 digits only";
	String MESSAGE3 = "Age should be between 1 to 100";
	String MESSAGE4 = "Enter valid email";
	String MESSAGE5 = "Please enter date of joining correctly";

}
