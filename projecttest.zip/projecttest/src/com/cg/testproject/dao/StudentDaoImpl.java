package com.cg.testproject.dao;

import java.util.HashMap;

import com.cg.testproject.dto.StudentDto;

public class StudentDaoImpl implements IStudentDao{
	
	private static HashMap<String, String> CollegeMap = null;
	private static HashMap<Integer, StudentDto> studentMap = null;
	static {
		studentMap = new HashMap<>();
		CollegeMap = new HashMap<>();
		CollegeMap.put("Delhi", "IIT-Delhi");
		CollegeMap.put("Hyderabad", "IIT-Hyderabad");
		CollegeMap.put("Chennai", "IIT-Chennai");
		CollegeMap.put("Bangalore", "IISc-Bangalore");
		CollegeMap.put("Mumbai", "IIT-Mumbai");
	}
	@Override
	public String showCollegeName(String city) {
		return CollegeMap.get(city);
	}
	@Override
	public StudentDto showStudent(int id) {
		return studentMap.get(id);
	}
	@Override
	public void addStudent(StudentDto studentDto) {
		studentMap.put(studentDto.getId(), studentDto);
	}

}
