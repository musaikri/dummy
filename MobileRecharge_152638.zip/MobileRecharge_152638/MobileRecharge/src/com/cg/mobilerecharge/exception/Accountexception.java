package com.cg.mobilerecharge.exception;

public class Accountexception extends Exception {

	public Accountexception() {
		super();
	}

	public Accountexception(String arg0) {
		super(arg0);
	}

}
