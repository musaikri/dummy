package com.cg.pt1.service;

import java.util.List;

import com.cg.pt1.dto.Product;

public interface IProductService {

	public void addProduct(Product pro);

	public List<Product> showAllData();

	public Product searchProduct(int prodid);

	public void removeProduct(int proid);
}
